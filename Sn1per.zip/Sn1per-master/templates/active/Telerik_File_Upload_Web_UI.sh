AUTHOR='@xer0dayz'
VULN_NAME='Telerik File Upload Web UI'
URI='/Telerik.Web.UI.WebResource.axd?type=rau'
METHOD='GET'
MATCH="RadAsyncUpload\ handler\ is\ registered\ succesfully"
SEVERITY='P2 - HIGH'
CURL_OPTS="--user-agent '' -s -L --insecure"
SECONDARY_COMMANDS=''
GREP_OPTIONS='-i'