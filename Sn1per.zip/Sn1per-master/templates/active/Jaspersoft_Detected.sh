AUTHOR='@xer0dayz'
VULN_NAME='Jaspersoft Detected'
URI='/jasperserver/login.html?error=1'
METHOD='GET'
MATCH="Jaspersoft"
SEVERITY='P5 - INFO'
CURL_OPTS="--user-agent '' -s -L --insecure"
SECONDARY_COMMANDS=''
GREP_OPTIONS='-i'